/**
 * 
 */
/**
 * 
 */
module Products_Fetching {
	requires java.sql;
}